is_employee = False

if not is_employee:
    print("fei gong wu ru")
