python_score = 78
c_score = 80

if python_score > 60 or c_score > 60:

    print("kao shi tong guo")

else:
    print("kao shi bu tong guo ")