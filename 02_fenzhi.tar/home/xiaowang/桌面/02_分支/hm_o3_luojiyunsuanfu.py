
age = 123
if age >= 0 and age<= 120:

    print("nian ling zheng que")

else:
    print("nian ling cuo wu")