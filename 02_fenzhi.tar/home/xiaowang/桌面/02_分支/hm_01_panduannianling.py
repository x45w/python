age = 23

if age >= 18:


    print("ni yi cheng nian:")
    print("ni yi cheng nian:")

print("ni yi cheng nian:")