holiday_name = "sheng ri"

if holiday_name == "qing ren jie":
    print("mai mei gui")
    print("kan dian ying")

elif holiday_name =="ping an ye":
    print("mai ping guo")
    print("chi da can")

elif holiday_name == "sheng ri":
    print("mai dan gao")

else:
    print("mei tian dou shi jie ri")