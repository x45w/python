
age = 15

if age >= 18:

    print("ni yi cheng nian")

else:
    print("hai wei cheng nian ")